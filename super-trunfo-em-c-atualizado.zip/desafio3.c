#include <stdio.h>

typedef struct {
    char nome[30];
    int forca;
    int velocidade;
    int inteligencia;
} Carta;

int main() {
    Carta carta1 = {"Águia", 55, 90, 70};
    Carta carta2 = {"Cobra", 65, 85, 75};

    int pontos1 = 0, pontos2 = 0;

    // Força
    carta1.forca > carta2.forca ? pontos1++ : (carta1.forca < carta2.forca ? pontos2++ : 0);
    // Inteligência
    carta1.inteligencia > carta2.inteligencia ? pontos1++ : (carta1.inteligencia < carta2.inteligencia ? pontos2++ : 0);

    pontos1 > pontos2 ? printf("Carta 1 venceu!\n") :
    pontos2 > pontos1 ? printf("Carta 2 venceu!\n") :
    printf("Empate!\n");

    return 0;
}