# 🃏 Super Trunfo em C

Projeto acadêmico desenvolvido para a disciplina de **Lógica de Programação** da Estácio. O objetivo é simular o jogo **Super Trunfo**, com foco na implementação de estruturas de decisão em C (`if`, `else if`, `switch` e operador ternário).

## 🔍 O que o projeto cobre

- Comparação entre cartas com diferentes atributos.
- Interação com o jogador via terminal.
- Evolução da lógica do jogo em três etapas:
  1. Comparação simples com `if` e `if-else`.
  2. Comparação com múltiplos atributos e menus (`switch`).
  3. Lógica mais avançada com operador ternário.

## 📁 Estrutura

- `desafio1.c`: Implementação básica com `if` e `if-else`
- `desafio2.c`: Uso de múltiplos atributos e `switch`
- `desafio3.c`: Uso de operador ternário para comparação

## 🧪 Exemplo no terminal

```
Escolha o atributo para comparar:
1 - Força
2 - Velocidade
3 - Inteligência
Opção: 1
Carta 1 venceu!
```

## 🚀 Como compilar

Utilize o GCC ou outro compilador C para rodar os arquivos:

```bash
gcc desafio1.c -o desafio1
./desafio1
```

(Repita para os demais arquivos)

## 👨‍💻 Tecnologias utilizadas

- Linguagem C
- GCC para compilação
- Terminal (CLI)

## 📚 Licença

Projeto educacional - uso livre com fins acadêmicos.