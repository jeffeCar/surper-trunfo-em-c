#include <stdio.h>

typedef struct {
    char nome[30];
    int forca;
    int velocidade;
    int inteligencia;
} Carta;

int main() {
    Carta carta1 = {"Leão", 70, 60, 40};
    Carta carta2 = {"Tigre", 65, 65, 45};

    int atributo;

    printf("Escolha o atributo para comparar:\n");
    printf("1 - Força\n2 - Velocidade\n3 - Inteligência\nOpção: ");
    scanf("%d", &atributo);

    if (atributo == 1) {
        if (carta1.forca > carta2.forca) {
            printf("Carta 1 venceu!\n");
        } else if (carta2.forca > carta1.forca) {
            printf("Carta 2 venceu!\n");
        } else {
            printf("Empate!\n");
        }
    } else if (atributo == 2) {
        if (carta1.velocidade > carta2.velocidade) {
            printf("Carta 1 venceu!\n");
        } else if (carta2.velocidade > carta1.velocidade) {
            printf("Carta 2 venceu!\n");
        } else {
            printf("Empate!\n");
        }
    } else if (atributo == 3) {
        if (carta1.inteligencia > carta2.inteligencia) {
            printf("Carta 1 venceu!\n");
        } else if (carta2.inteligencia > carta1.inteligencia) {
            printf("Carta 2 venceu!\n");
        } else {
            printf("Empate!\n");
        }
    } else {
        printf("Atributo inválido!\n");
    }

    return 0;
}