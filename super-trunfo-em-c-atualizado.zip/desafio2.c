#include <stdio.h>

typedef struct {
    char nome[30];
    int forca;
    int velocidade;
    int inteligencia;
} Carta;

int main() {
    Carta carta1 = {"Pantera", 60, 80, 55};
    Carta carta2 = {"Urso", 75, 60, 50};

    int menu;
    printf("Escolha uma comparação:\n");
    printf("1 - Força e Velocidade\n");
    printf("2 - Velocidade e Inteligência\n");
    printf("3 - Força e Inteligência\n");
    printf("Opção: ");
    scanf("%d", &menu);

    int pontos1 = 0, pontos2 = 0;

    switch(menu) {
        case 1:
            if (carta1.forca > carta2.forca) pontos1++; else if (carta2.forca > carta1.forca) pontos2++;
            if (carta1.velocidade > carta2.velocidade) pontos1++; else if (carta2.velocidade > carta1.velocidade) pontos2++;
            break;
        case 2:
            if (carta1.velocidade > carta2.velocidade) pontos1++; else if (carta2.velocidade > carta1.velocidade) pontos2++;
            if (carta1.inteligencia > carta2.inteligencia) pontos1++; else if (carta2.inteligencia > carta1.inteligencia) pontos2++;
            break;
        case 3:
            if (carta1.forca > carta2.forca) pontos1++; else if (carta2.forca > carta1.forca) pontos2++;
            if (carta1.inteligencia > carta2.inteligencia) pontos1++; else if (carta2.inteligencia > carta1.inteligencia) pontos2++;
            break;
        default:
            printf("Opção inválida.\n");
            return 1;
    }

    if (pontos1 > pontos2) printf("Carta 1 venceu!\n");
    else if (pontos2 > pontos1) printf("Carta 2 venceu!\n");
    else printf("Empate!\n");

    return 0;
}